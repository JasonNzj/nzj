package cn.zhangxd.platform.common.service.datasource;

public enum DynamicDataSourceGlobal {
    /**
     * 读数据源
     */
    READ,
    /**
     * 写数据源
     */
    WRITE
}