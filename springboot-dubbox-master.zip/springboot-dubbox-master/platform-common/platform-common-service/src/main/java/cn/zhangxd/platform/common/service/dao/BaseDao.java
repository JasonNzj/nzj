package cn.zhangxd.platform.common.service.dao;

/**
 * DAO支持类实现
 *
 * @author zhangxd
 */
public interface BaseDao {

}